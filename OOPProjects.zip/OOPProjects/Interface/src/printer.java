interface Printer {
    void print();
}
