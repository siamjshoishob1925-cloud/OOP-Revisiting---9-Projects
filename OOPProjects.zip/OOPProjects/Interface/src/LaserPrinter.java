class LaserPrinter implements Printer {
    public void print() {
        System.out.println("Printing using Laser Printer...");
    }
}
