class Student {
    private String name;
    private int age;

    public void setDetails(String n, int a) {
        name = n;
        age = a;
    }

    public void showDetails() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
