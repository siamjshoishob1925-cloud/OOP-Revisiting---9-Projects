
public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.setDetails("Saiba", 20);
        s.showDetails();
    }
}
