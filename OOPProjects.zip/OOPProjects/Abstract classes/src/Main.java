public class Main {
    public static void main(String[] args) {
        Circle c = new Circle(5);
        c.info();
        System.out.println("Circle area: " + c.area());
    }
}
