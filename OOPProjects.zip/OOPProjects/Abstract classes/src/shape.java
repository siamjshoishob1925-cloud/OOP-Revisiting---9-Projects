abstract class Shape {
    abstract double area();

    void info() {
        System.out.println("This is a shape.");
    }
}
