public class Main {
    public static void main(String[] args) {
        Parrot p = new Parrot();
        p.fly();
        p.sing();
    }
}
