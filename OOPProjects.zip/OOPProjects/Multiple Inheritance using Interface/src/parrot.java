class Parrot implements flyable, singable {
    public void fly() {
        System.out.println("Parrot is flying...");
    }

    public void sing() {
        System.out.println("Parrot is singing...");
    }
}
