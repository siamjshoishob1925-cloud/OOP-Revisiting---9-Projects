interface singable {
    void sing();
}
