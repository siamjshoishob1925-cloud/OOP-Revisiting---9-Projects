interface flyable {
    void fly();
}
