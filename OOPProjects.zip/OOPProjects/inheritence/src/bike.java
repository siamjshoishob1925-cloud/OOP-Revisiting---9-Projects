class Bike extends Vehicle {
    void ride() {
        System.out.println(brand + " is riding fast!");
    }
}

