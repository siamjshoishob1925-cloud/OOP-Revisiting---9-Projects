class Vehicle {
    protected String brand = "Honda";

    void showType() {
        System.out.println("This is a vehicle.");
    }
}
