public class Main {
    public static void main(String[] args) {
        Bike b = new Bike();
        b.showType();
        b.ride();
    }
}
