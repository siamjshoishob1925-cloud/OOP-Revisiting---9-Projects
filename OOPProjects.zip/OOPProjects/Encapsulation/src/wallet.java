class Wallet {
    private double balance;

    public void addMoney(double amount) {
        if(amount > 0) balance += amount;
    }

    public void spendMoney(double amount) {
        if(amount <= balance) balance -= amount;
        else System.out.println("Insufficient funds!");
    }

    public double getBalance() {
        return balance;
    }
}
