public class Main {
    public static void main(String[] args) {
        Wallet w = new Wallet();
        w.addMoney(500);
        w.spendMoney(200);
        System.out.println("Wallet balance: " + w.getBalance());
    }
}
