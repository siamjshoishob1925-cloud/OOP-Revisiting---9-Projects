class Book {
    String title;
    String author;
    int pages;

    void showDetails() {
        System.out.println(title + " by " + author + ", Pages: " + pages);
    }
}
