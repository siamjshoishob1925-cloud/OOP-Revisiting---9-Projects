public class Main {
    public static void main(String[] args) {
        Book book1 = new Book();
        book1.title = "Java Fundamentals";
        book1.author = "Saiba Khan";
        book1.pages = 250;

        Book book2 = new Book();
        book2.title = "OOP Concepts";
        book2.author = "John Doe";
        book2.pages = 300;

        book1.showDetails();
        book2.showDetails();
    }
}
